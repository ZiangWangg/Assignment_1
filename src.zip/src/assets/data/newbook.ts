import { Bookdata } from '../../app/Bookdata';
export const BookData: Bookdata[] =[ 
  {Name: '',description: '',
  author: '',year:0,publisher: '',comments: ''}

];