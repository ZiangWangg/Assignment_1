import { Text } from '../../app/Bookdata';

export const TEXT : Text ={
  bookCollection : 'I have 200 books in my collection.',
  passion:'In my free time I like to read.'
}