import { Bookdata } from '../../app/Bookdata';
export const BookData: Bookdata[] =[ 
  {Name: 'Steve Jobs Hardcover1',description: 'Based on more than forty interviews with Steve Jobs conducted over two years',
  author: 'Walter Isaacson',year: 2011,publisher: 'Simon & Schuster',comments: 'Nice book'},
  {Name: 'Steve Jobs Hardcover2',description: 'Based on more than forty interviews with Steve Jobs conducted over two years',
  author: 'Walter Isaacson',year: 2011,publisher: 'Simon & Schuster',comments: 'Nice book'},
  {Name: 'Steve Jobs Hardcover3',description: 'Based on more than forty interviews with Steve Jobs conducted over two years',
  author: 'Walter Isaacson',year: 2011,publisher: 'Simon & Schuster',comments: 'Nice book'},
  {Name: 'Steve Jobs Hardcover4',description: 'Based on more than forty interviews with Steve Jobs conducted over two years',
  author: 'Walter Isaacson',year: 2011,publisher: 'Simon & Schuster',comments: 'Nice book'},
  {Name: 'Steve Jobs Hardcover5',description: 'Based on more than forty interviews with Steve Jobs conducted over two years',
  author: 'Walter Isaacson',year: 2011,publisher: 'Simon & Schuster',comments: 'Nice book'}
];

