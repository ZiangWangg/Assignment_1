export interface Bookdata {
  Name: string;  
  description: string;
  author: string;
  year: number;
  publisher: string;
  comments: string;
 
  }
  

  export interface Text {
    bookCollection: string;
    passion : string;
}